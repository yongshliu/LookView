
angular.module('contentDemo1', ['ngMaterial'])

.controller('AppCtrl', function($scope) {

});
